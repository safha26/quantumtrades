from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from .forms import UserRegistrationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import *
from .order_matching import *
from django.http import JsonResponse
from django.contrib.auth.models import User
from django.db import IntegrityError


# Create your views here.
def dashboard(request):
    buy_orders = Order.objects.filter(order_type='buy', status='active').order_by('-price', 'created_at')
    sell_orders = Order.objects.filter(order_type='sell', status='active').order_by('price', 'created_at')
    trades = Trade.objects.all().order_by('-timestamp')
    return render(request, 'trade/dashboard.html', {
        'buy_orders': buy_orders,
        'sell_orders': sell_orders,
        'trades': trades,
    })


def register_view(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                messages.success(request, "Registration successful. Please login.")
                return redirect('login')  # Update 'login' to your login URL name
            except Exception as e:
                form.add_error(None, f"An unexpected error occurred: {str(e)}")
    else:
        form = UserRegistrationForm()
    return render(request, 'trade/register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'trade/login.html')

@login_required
def place_order(request):
    if request.method == 'POST':
        order_type = request.POST.get('order_type')
        order_style = request.POST.get('order_style', 'limit')
        price = request.POST.get('price')
        quantity = int(request.POST.get('quantity'))

        if order_style == 'market':
            price = None

        order = Order.objects.create(
            user = request.user,
            order_type = order_type,
            order_style = order_style,
            price = price,
            quantity = quantity,
        )

        match_orders()
        messages.success(request, f"{order_type.capitalize()} Order placed successfully")
        return redirect('dashboard')
    return render(request, 'trade/place_order.html')

@login_required
def cancel_order(request, order_id):
    try:
        order = Order.objects.get(id=order_id, user=request.user, status='active')
        order.status = 'canceled'
        order.save()
        messages.success(request, "Order canceled successfully")
    except Order.DoesNotExist:
        messages.error(request, "Order does not exist")
    return redirect('dashboard')


def logout_view(request):
    logout(request)
    return redirect('login')

def order_book_api(request):
    buy_orders = list(Order.objects.filter(order_type='buy', status='active').values('price', 'quantity'))
    sell_orders = list(Order.objects.filter(order_type='sell', status='active').values('price', 'quantity'))
    return JsonResponse({'buy_orders': buy_orders,'sell_orders': sell_orders})

def trade_history_api(request):
    trades = list(Trade.objects.all().order_by('-timestamp').values('price', 'quantity', 'timestamp')[:30])
    return JsonResponse({'trades': trades})

@login_required
def your_dashboard(request):
    user_buy_orders = Order.objects.filter(user=request.user, order_type = 'buy', status='active')
    user_sell_orders = Order.objects.filter(user=request.user, order_type='sell', status='active')
    user_trades = Trade.objects.filter(
        buy_order__user=request.user).union(Trade.objects.filter(sell_order__user=request.user).order_by('-timestamp')
    )
    active_orders = request.user.order_set.filter(status='active')
    return render(request, 'trade/your_dashboard.html', {
        'active_orders': active_orders,
        'user_buy_orders': user_buy_orders,
        'user_sell_orders': user_sell_orders,
        'user_trades': user_trades,})
