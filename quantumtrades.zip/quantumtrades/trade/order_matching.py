from .models import Order, Trade
from django.db import transaction
from decimal import Decimal

@transaction.atomic
def match_orders():
    buy_orders = Order.objects.filter(order_type='buy', status = 'active').order_by('-price','created_at')
    sell_orders = Order.objects.filter(order_type='sell', status = 'active').order_by('price','created_at')

    for buy_order in buy_orders:
        for sell_order in sell_orders:
            if sell_order.price is not None and buy_order.price is not None:
                if sell_order.price <= buy_order.price and buy_order.quantity > buy_order.quantity_filled and sell_order.quantity >sell_order.quantity_filled:
                    match_qty = min(buy_order.quantity - buy_order.quantity_filled, sell_order.quantity-sell_order.quantity_filled)
                    trade_price = sell_order.price

                    # To Update filled quantities
                    buy_order.quantity_filled += match_qty
                    sell_order.quantity_filled += match_qty

                    #Creating trade record
                    Trade.objects.create(
                        buy_order = buy_order,
                        sell_order = sell_order,
                        price = trade_price,
                        quantity = match_qty,
                    )

                    if buy_order.quantity_filled == buy_order.quantity:
                        buy_order.status = 'completed'
                    if sell_order.quantity_filled == sell_order.quantity:
                        sell_order.status = 'completed'

                    buy_order.save()
                    sell_order.save()

                    if buy_order.status == 'completed':
                        break

